@echo off
setlocal

REM === CONFIG ===
set APPNAME=Alphy.exe
set INSTALLDIR=%~1
set TEMPZIP=%TEMP%\update.zip
set TEMPEXTRACT=%TEMP%\update_extract

echo Starting update...

REM === Wait until app is closed ===
:waitloop
tasklist /FI "IMAGENAME eq %APPNAME%" | find /I "%APPNAME%" >nul
if "%ERRORLEVEL%"=="0" (
    echo Waiting for %APPNAME% to close...
    timeout /t 2 >nul
    goto waitloop
)

REM === Clean temp extract folder ===
if exist "%TEMPEXTRACT%" rmdir /s /q "%TEMPEXTRACT%"
mkdir "%TEMPEXTRACT%"

REM === Extract update.zip ===
echo Extracting update...
powershell -Command "Add-Type -A 'System.IO.Compression.FileSystem'; [IO.Compression.ZipFile]::ExtractToDirectory('%TEMPZIP%', '%TEMPEXTRACT%')"

REM === Copy files ===
echo Copying new files...
xcopy "%TEMPEXTRACT%\*" "%INSTALLDIR%\" /E /Y /I

REM === Restart app ===
echo Restarting app...
start "" "%INSTALLDIR%\%APPNAME%"

echo Update complete!
exit